# MaltaJobsHub Pro

A static, mobile-friendly Malta career website starter.

## Included
- Home page
- Job category/search page
- CV service/pricing page
- Interview preparation
- Salary calculator
- Career resources
- Privacy and Terms placeholders
- 404 page
- Responsive CSS and JavaScript

## Before launch
1. Replace `hello@example.com` in `cv.html` and `assets/app.js` with your real business email.
2. Replace sample job categories with verified, current vacancies and original application links.
3. Review the salary calculator against current official Maltese tax/social-security rules before publishing it as a financial calculator.
4. Replace the placeholder Privacy Policy and Terms with documents appropriate to your actual business and data processing.
5. Add your payment provider only after you have decided the service/refund workflow.
6. Add analytics/advertising only after preparing the required disclosures/consent where applicable.

## Free publishing
This is a static site and can be published with GitHub Pages. GitHub's official documentation explains how to create a repository and publish an `index.html` site.
